package community;

public class Super_main {

	public static void main(String[] args) {
		Subsuper ss=new Subsuper();
		ss.think();
		

	}
}
