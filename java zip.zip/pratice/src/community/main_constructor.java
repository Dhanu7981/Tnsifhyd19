package community;

public class main_constructor {
	public  main_constructor() {
		System.out.println("its default constructor");
		
	}

}



