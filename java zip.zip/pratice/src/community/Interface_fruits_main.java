package community;

public class Interface_fruits_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Interface_fruits a=new apple();
		a.fruits();
		Interface_fruits b=new banana();
		b.fruits();
		Interface_fruits o=new orange();
		o.fruits();

	}

}
