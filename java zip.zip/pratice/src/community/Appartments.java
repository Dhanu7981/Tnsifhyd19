package community;

public class Appartments {
	
		public void floors() {
			System.out.println("its first");
		}
		public void floors1() {
			System.out.println("its second");
		}
		public void floors2() {
			System.out.println("its third");
		}
	

}
