package community;

public interface Interface_fruits {
	public void fruits();

}
class apple implements Interface_fruits{
	public void fruits() {
		System.out.println("its apple");
	}
}
class banana implements Interface_fruits{
	public void fruits() {
		System.out.println("its banana");
	}
}
class orange implements Interface_fruits{
	public void fruits() {
		System.out.println("its orange");
	}
}
