package community;

public class Hierarichal_inheritance {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Hierarichal h=new Hierarichal();
		h.first();
		parent p=new parent();
		p.first();
		child c= new child();
		c.first();
	}

}
