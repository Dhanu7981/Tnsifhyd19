package community;

public interface Interface_lambda {
	
	void peacock();
	public static void main(String[] args) {

	Interface_lambda il=()->System.out.println("it dances");
	il.peacock();
		
	}
}
