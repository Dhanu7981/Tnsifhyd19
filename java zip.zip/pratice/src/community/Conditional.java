package community;

public class Conditional {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

		int age=25;
		if(age<18) {
			System.out.println("you are minor");
			
		}
		else if(18>age || age<50){
			System.out.println("you are adult");
		}
		else{
			System.out.println("you became old");
		}
	}

}
