package community;

abstract class Abstract {
	public void play() {}
	
}
class plays extends Abstract{
	public void play(){
		System.out.println("playing");
	}
}
class noplays extends Abstract{
	public void play(){
		System.out.println("not playing");
	}
	
}
