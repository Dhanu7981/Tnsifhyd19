package community;

public class Abstract_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


	Abstract a=new plays();
	a.play();
	Abstract aa=new noplays();
	aa.play();
	}	

}
