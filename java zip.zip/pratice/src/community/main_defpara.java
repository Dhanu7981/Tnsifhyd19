package community;

public class main_defpara {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				main_constructor c=new main_constructor();
				para_const p = new para_const("its parametrized");


}

}
