package community;

public class single_inheritance {
	public static void main(String[] args) {
		subsingle sb=new subsingle();
		sb.meth();
		single s=new single();
		s.meth();
	}

}
