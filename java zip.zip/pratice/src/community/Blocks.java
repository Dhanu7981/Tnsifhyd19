package community;

public class Blocks {
	public void name() {
		System.out.println("its gated community");
	}
	public void gate() {
		System.out.println("its having 4");
	}
	public void paths() {
		System.out.println("its having many paths");
	}
}

