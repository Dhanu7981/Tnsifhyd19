package community;

public class para_const {
	
		public  para_const(String a) {
			System.out.println(a);
		}



}
