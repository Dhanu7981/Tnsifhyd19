package community;

public class Subsuper extends Super {
		int a=30;
		
		public void think() {
		System.out.println("thinking by sub");
		
		System.out.println(super.a);
		System.out.println(a);
		
		super.think();
		}
		
		

	
}
