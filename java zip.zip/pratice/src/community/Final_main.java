package community;

public class Final_main {
	int a=20;
	public static void main(String[] args) {
		
		Final f=new Final();
		f.method();
		System.out.println(f.a);
	}

}
