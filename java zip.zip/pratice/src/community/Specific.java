package community;

public class Specific {
	
		public void garden() {
			System.out.println("its contains garden");
		}
		public void swimmingpool() {
			System.out.println("its contains swimmingpool");
		}
		public void gym() {
			System.out.println("its contains gym");
		}
	




}
