package community;

public class multilevel{
	public void first() {
		System.out.println("grand father");
		
	}

}
class parent extends multilevel{
	public void first() {
		System.out.println("parent");
		
	}
	
}
class child extends parent{
	public void first() {
		System.out.println("child");
		
	}

	
	
	}

