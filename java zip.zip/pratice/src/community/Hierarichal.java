package community;

public class Hierarichal {
	public void first() {
		System.out.println("grand father");
		
	}

}
class parent extends Hierarichal {
	public void first() {
		System.out.println("parent");
		
	}
	
}
class child extends Hierarichal {
	public void first() {
		System.out.println("child");
		
	}

	

}
