package community;

final class Final {
	final int a=10;
	//int a=20;
	final void method() {
		System.out.println("its final");
	}
	
}
/*class subclass extends Final{
	void method() {
		System.out.println("its extended final");
	}
	
}
*/