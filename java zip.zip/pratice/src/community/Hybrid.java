package community;

public class Hybrid {
	public void first() {
		System.out.println("grand father");
		
	}

}
class parent extends Hybrid{
	public void first() {
		System.out.println("parent");
		
	}
	
}
class child extends parent {
	public void first() {
		System.out.println("child");
		
	}
}
class grandchild extends Hybrid {
	public void first() {
		System.out.println("grand child");
		
	}

	


}
