package community;

public class Fun_private {
		public String employeee="developer";
		private long phoneno;
		private int id;
		private String address;
		public String accsess() {
			if (employeee.equals("developer") && address.equals("hyd")) {
				return "its me"	;		}
			else {
				return "its not me";
			}
		}
		
		public long getPhoneno() {
			return phoneno;
		}
		
		public  void setPhoneno(long phoneno) {
			this.phoneno = phoneno;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getAddress() {
			return address;
		}
		public  void setAddress(String address) {
			this.address = address;
		}
		
		public static void main(String[] args) {
			Fun_private  r= new Fun_private ();
			r.setPhoneno(758587);
			System.out.println(r.getPhoneno());
			r.setId(78);
			System.out.println(r.getId());
			r.setAddress("hyd");
			System.out.println(r.getAddress());
			System.out.println(r.employeee);
			System.out.println(r.accsess());
		}


}
