package community;

public class mutlilevel_inheritance {

	
		public static void main(String[] args) {
			parent p=new parent();
			p.first();
			child c=new child();
			c.first();
			
			
		}
}
