package community;

public class subsingle extends single{
		
		public void meth() {
			System.out.println("its me child in single inheritance");
		}

	

}
