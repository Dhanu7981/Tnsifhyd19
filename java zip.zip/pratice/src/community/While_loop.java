package community;

public class While_loop {
	public static void main(String[] args) {
	int i=0;
	while(i<=200){
		System.out.println(i);
		i+=5;
	}
}

}
