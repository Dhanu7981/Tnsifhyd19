package community;

public class For_loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=2;
		for(i=0;i<40;i+=2) {
			System.out.println(i);
			
		}
	}

}
