package community;

public class Hybrid_inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Hybrid h=new Hybrid();
		h.first();
		parent p=new parent();
		p.first();
		child c=new child();
		c.first();
		grandchild gc=new grandchild();
		gc.first();

}
}
