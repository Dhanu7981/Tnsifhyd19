package community;

public class dowhile_loop {
	public static void main(String[] args) {
		int i=0;
		do {
			System.out.println(i);
			i+=5;
		}while(i<=20);
	}

}
