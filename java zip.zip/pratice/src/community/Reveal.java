package community;

public class Reveal{
	public String employeee="developer";
	private long phoneno;
	private int id;
	private String address;
	
	public long getPhoneno() {
		return phoneno;
	}
	
	public  void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public  void setAddress(String address) {
		this.address = address;
	}
	
	public static void main(String[] args) {
		Reveal r= new Reveal();
		r.setPhoneno(758587);
		System.out.println(r.getPhoneno());
		r.setId(78);
		System.out.println(r.getId());
		r.setAddress("hyd");
		System.out.println(r.getAddress());
		System.out.println(r.employeee);
	}
}
