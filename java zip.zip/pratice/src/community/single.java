package community;

public class single {
	public void meth() {
		System.out.println("its me parent in single inheritance");
	}
}
