package community;

public class Secret {
	public String employeee;
	private long phoneno;
	private int id;
	private String address;
	


	public static void main(String[] args) {
		Secret s= new Secret();
		s.employeee="developer";
		s.phoneno=653287;
		System.out.println(s.employeee);
		System.out.println(s.phoneno); //its possible to acsses private member inside the same class
		
	}
	public class outside{
		System.out.println(s.phoneno); //its not possible private members out side the class
		
	}
}
