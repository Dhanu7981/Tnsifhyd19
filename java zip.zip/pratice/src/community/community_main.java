package community;

import community.*;
public class community_main {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Blocks b=new Blocks();
		b.name();
		b.gate();
		b.paths();
		Appartments a=new Appartments ();
		a.floors();
		a.floors1();
		a.floors2();
		Specific s=new Specific();
		s.garden();
		s.swimmingpool();
		s.gym();
		

	}

}
