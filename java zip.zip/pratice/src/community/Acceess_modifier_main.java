package community;

public class Acceess_modifier_main {

	public static void main(String[] args) {
		
		
				 Acesss_modifiers am=new  Acesss_modifiers();
				 System.out.println(am.a);
				 System.out.println(am.b);
				 //System.out.println(am.c);
				 System.out.println(am.d);
				 
			}
		

		// TODO Auto-generated method stub

	}


