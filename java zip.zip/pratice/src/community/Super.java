package community;

public class Super {
	int a=10;
	public void think() {
		System.out.println("thinking");
	}
	public Super(){
		
			System.out.println("saying");
		}		
	
}
